## GUI - 空格
clear @a minecraft:iron_horse_armor{CustomModelData:600001} 256

## GUI - 返回
clear @a minecraft:iron_horse_armor{CustomModelData:600002} 256

## GUI - 蓝图工艺
clear @a minecraft:iron_horse_armor{CustomModelData:600003} 256

## GUI - 初级战斗
clear @a minecraft:iron_horse_armor{CustomModelData:600004} 256

## GUI - 机械方块
clear @a minecraft:iron_horse_armor{CustomModelData:600005} 256

## GUI - 学徒笔记
clear @a minecraft:iron_horse_armor{CustomModelData:600006} 256

## GUI - 工艺蓝本
clear @a minecraft:iron_horse_armor{CustomModelData:600007} 256

## GUI - 神秘蓝本
clear @a minecraft:iron_horse_armor{CustomModelData:600008} 256

## GUI - 神秘蓝本
clear @a minecraft:iron_horse_armor{CustomModelData:600009} 256