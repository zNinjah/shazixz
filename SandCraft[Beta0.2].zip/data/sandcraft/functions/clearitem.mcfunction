## GUI - 空格
kill @e[type=item,nbt={Item:{id:"minecraft:iron_horse_armor",tag:{CustomModelData:600001}}}]

## GUI - 返回
kill @e[type=item,nbt={Item:{id:"minecraft:iron_horse_armor",tag:{CustomModelData:600002}}}]

## GUI - 蓝图工艺
kill @e[type=item,nbt={Item:{id:"minecraft:iron_horse_armor",tag:{CustomModelData:600003}}}]

## GUI - 初级战斗
kill @e[type=item,nbt={Item:{id:"minecraft:iron_horse_armor",tag:{CustomModelData:600004}}}]

## GUI - 机械方块
kill @e[type=item,nbt={Item:{id:"minecraft:iron_horse_armor",tag:{CustomModelData:600005}}}]

## GUI - 学徒笔记
kill @e[type=item,nbt={Item:{id:"minecraft:iron_horse_armor",tag:{CustomModelData:600006}}}]

## GUI - 工艺蓝本
kill @e[type=item,nbt={Item:{id:"minecraft:iron_horse_armor",tag:{CustomModelData:600007}}}]

## GUI - 神秘蓝本
kill @e[type=item,nbt={Item:{id:"minecraft:iron_horse_armor",tag:{CustomModelData:600008}}}]

## GUI - 神秘蓝本
kill @e[type=item,nbt={Item:{id:"minecraft:iron_horse_armor",tag:{CustomModelData:600009}}}]