## 去除覆盖
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if block ~ ~ ~ air run kill @e[type=minecraft:item_display,distance=..0.7]

## 去除代理实体
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if block ~ ~ ~ air run kill @s