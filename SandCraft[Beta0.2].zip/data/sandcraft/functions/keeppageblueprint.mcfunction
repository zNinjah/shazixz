##返回
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:26b, id:"minecraft:iron_horse_armor"}] run data modify block ~ ~ ~ CustomName set value "主界面"

##蓝图界面加载
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺-temp"'} run function sandcraft:pageblueprint

##第一行
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:0b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:1b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:2b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:3b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:4b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:5b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:6b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:7b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:8b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint

##第二行
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:9b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:17b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint

##第一行
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:18b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:19b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:20b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:21b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:22b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:23b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:24b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:25b, id:"minecraft:iron_horse_armor"}] run function sandcraft:pageblueprint

##进入合成
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:10b, id:"minecraft:iron_horse_armor"}] run data modify block ~ ~ ~ CustomName set value "合成界面-temp"
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:11b, id:"minecraft:iron_horse_armor"}] run data modify block ~ ~ ~ CustomName set value "合成界面-temp"
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:12b, id:"minecraft:iron_horse_armor"}] run data modify block ~ ~ ~ CustomName set value "合成界面-temp"
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:13b, id:"minecraft:iron_horse_armor"}] run data modify block ~ ~ ~ CustomName set value "合成界面-temp"
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:14b, id:"minecraft:iron_horse_armor"}] run data modify block ~ ~ ~ CustomName set value "合成界面-temp"
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:15b, id:"minecraft:iron_horse_armor"}] run data modify block ~ ~ ~ CustomName set value "合成界面-temp"
execute as @e[type=minecraft:armor_stand,tag=crafter] at @s if data block ~ ~ ~ {CustomName:'"蓝图工艺"'} unless data block ~ ~ ~ Items[{Slot:16b, id:"minecraft:iron_horse_armor"}] run data modify block ~ ~ ~ CustomName set value "合成界面-temp"