## 第一行
item replace block ~ ~ ~ container.0 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.1 with air
item replace block ~ ~ ~ container.2 with air
item replace block ~ ~ ~ container.3 with air
item replace block ~ ~ ~ container.4 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.5 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.6 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.7 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.8 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1

## 第二行
item replace block ~ ~ ~ container.9 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.10 with air
item replace block ~ ~ ~ container.11 with air
item replace block ~ ~ ~ container.12 with air
item replace block ~ ~ ~ container.13 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.14 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.15 with air
item replace block ~ ~ ~ container.16 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.17 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1

## 第三行
item replace block ~ ~ ~ container.18 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.19 with air
item replace block ~ ~ ~ container.20 with air
item replace block ~ ~ ~ container.21 with air
item replace block ~ ~ ~ container.22 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.23 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.24 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.25 with iron_horse_armor{display:{Name:'{"text":"","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.26 with iron_horse_armor{display:{Name:'{"text":"返回上一页","italic":false,"color":"red"}'},CustomModelData:600002} 1

##修改名字
data modify block ~ ~ ~ CustomName set value "合成界面"