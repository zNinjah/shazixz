## 第一行
item replace block ~ ~ ~ container.0 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.1 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.2 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.3 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.4 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.5 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.6 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.7 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.8 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1

## 第二行
item replace block ~ ~ ~ container.9 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.10 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.11 with iron_horse_armor{display:{Name:'{"text":"蓝图工艺","italic":false,"color":"aqua"}',Lore:["{\"text\":\"万物之始\",\"color\":\"dark_purple\",\"bold\":false,\"italic\":false,\"underlined\":false,\"strikethrough\":false,\"obfuscated\":false}"]},CustomModelData:600003} 1
item replace block ~ ~ ~ container.12 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.13 with iron_horse_armor{display:{Name:'{"text":"初级战斗","italic":false,"color":"aqua"}',Lore:["{\"text\":\"萌新の第一步\",\"color\":\"dark_purple\",\"bold\":false,\"italic\":false,\"underlined\":false,\"strikethrough\":false,\"obfuscated\":false}"]},CustomModelData:600004} 1
item replace block ~ ~ ~ container.14 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.15 with iron_horse_armor{display:{Name:'{"text":"机械方块","italic":false,"color":"aqua"}',Lore:["{\"text\":\"迈向新世界\",\"color\":\"dark_purple\",\"bold\":false,\"italic\":false,\"underlined\":false,\"strikethrough\":false,\"obfuscated\":false}"]},CustomModelData:600005} 1
item replace block ~ ~ ~ container.16 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.17 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1

## 第三行
item replace block ~ ~ ~ container.18 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.19 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.20 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.21 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.22 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.23 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.24 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.25 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1
item replace block ~ ~ ~ container.26 with iron_horse_armor{display:{Name:'{"text":"这里什么都没有哦~","italic":false,"color":"gray"}'},CustomModelData:600001} 1